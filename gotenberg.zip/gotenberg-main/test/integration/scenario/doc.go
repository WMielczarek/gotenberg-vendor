// Package scenario gathers all steps used in the features.
package scenario
