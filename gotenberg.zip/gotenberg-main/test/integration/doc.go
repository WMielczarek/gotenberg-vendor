// Package integration contains everything related to integration testing.
package integration
