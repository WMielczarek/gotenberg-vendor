// Package standard imports the application's default modules.
package standard
