// Package pdfengines a way to gather and manage multiple modules that
// implement the gotenberg.PdfEngine interface.
package pdfengines
