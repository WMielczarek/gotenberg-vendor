// Package webhook provides a module which adds a middleware for uploading
// output files to any destination in an asynchronous fashion.
package webhook
