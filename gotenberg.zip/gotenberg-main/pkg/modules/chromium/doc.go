// Package chromium provides a module which adds routes for converting HTML
// documents to PDF. Other modules may also retrieve the [Api] provided by this
// module.
package chromium
